function addUser() {

    var catalyst = require('zcatalyst-sdk-node');

	console.log("yes");
module.exports = (req, res) => {	
    var app = catalyst.initialize(req); 
//This app variable is used to access the catalyst components.
//You can refer the SDK docs for code samples.
//Your business logic comes here
}
console.log("yep");

	var signupConfig = {
		platform_type: 'web',
		zaid: 50010652417
	};
  var userConfig = {
		last_name: 'Boyle',
		email_id: 'tamilselvan2020ai@gmail.com',
		role_id : '2218000000009016'
	  };

  const myObj = {"name":"John", "age":30, "car":null};
	document.getElementById("demo").innerHTML = userConfig.last_name;

  
  let userManagement = app.userManagement();

  console.log("1");
  let registerPromise = userManagement.registerUser(signupConfig, userConfig); //Pass the JSON configration to the method
  console.log(2);
  registerPromise.then(userDetails => {  //Returns a promise
  console.log(userDetails); 
  });

  console.log(3);}





